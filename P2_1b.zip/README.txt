I am using the online Google Cloud Platform with Sentiment Analysis using Google Cloud Natural Language API.

Also use the built-in Orion editor in Cloud Shell.

My API key: AIzaSyB2WOimhvfg0QJCO4CdrU9H2KAFsdNk87k

I have created the .json file and made some trials in the terminal command lines.

.json file:
{
"document":{
"type":"PLAIN_TEXT",
"content":"(text)"
},
"encodingType": "UTF8"
}

Here are the commands:
curl "https://language.googleapis.com/v1/documents:analyzeSentiment?key=${API_KEY}" -s -X POST -H "Content-Type: application/json" --data-binary @request.json

The screen shots are in the zip file.